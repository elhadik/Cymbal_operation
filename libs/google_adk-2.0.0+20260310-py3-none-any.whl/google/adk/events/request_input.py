# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from __future__ import annotations

from typing import Any
from typing import Optional
import uuid

from pydantic import BaseModel
from pydantic import Field


class RequestInput(BaseModel):
  """Represents a request for input from the user."""

  interrupt_id: str = Field(
      description=(
          "The ID of the interrupt, usually a function call ID. This is used"
          " to identify the interrupt that the input is for."
      ),
      default_factory=lambda: str(uuid.uuid4()),
  )
  """The ID of the interrupt, usually a function call ID.

  Important: When using HITL inside a loop (e.g. a rejection/retry cycle),
  use a **unique interrupt_id per iteration** (e.g. ``f'review_{count}'``).
  Reusing the same interrupt_id across iterations causes event-based state
  reconstruction to confuse earlier resolved responses with the current
  interrupt, resulting in an infinite restart loop.
  """
  payload: Optional[Any] = None
  """ Custom payload to be provided for resuming."""
  message: Optional[str] = Field(
      None,
      description="A message to display to the user when requesting input.",
  )
  """A message to display to the user when requesting input."""
  response_schema: Optional[dict[str, Any]] = Field(
      None,
      description=(
          "The expected JSON schema of the response. If None, it defaults to"
          " Any."
      ),
  )
  """The expected JSON schema of the response."""
